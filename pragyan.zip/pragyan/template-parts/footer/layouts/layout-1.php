<div class="col-lg-12 col-md-12">
	<div class="footer-widget-area">
		<?php dynamic_sidebar( 'footer-1' ); ?>
	</div>
</div>
