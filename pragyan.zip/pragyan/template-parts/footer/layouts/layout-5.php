<div class="col-lg-3 col-md-4">
	<div class="footer-widget-area">
		<?php dynamic_sidebar( 'footer-1' ); ?>
	</div>
</div>
<div class="col-lg-6 col-md-4">
	<div class="footer-widget-area">
		<?php dynamic_sidebar( 'footer-2' ); ?>
	</div>
</div>
<div class="col-lg-3 col-md-4">
	<div class="footer-widget-area">
		<?php dynamic_sidebar( 'footer-3' ); ?>
	</div>
</div>
