<div class="col-lg-6 col-md-6">
	<div class="footer-widget-area">
		<?php dynamic_sidebar( 'footer-1' ); ?>
	</div>
</div>
<div class="col-lg-6 col-md-6">
	<div class="footer-widget-area">
		<?php dynamic_sidebar( 'footer-2' ); ?>
	</div>
</div>
