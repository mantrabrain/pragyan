<div class="footer-top">
	<div class="container">
		<div class="row footer-wrap">
			<?php
			do_action('pragyan_top_footer_widget_area')
			?>
		</div>
	</div>
</div>
