<div class="pragyan-home-page-main-content-area">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-8">
				<?php dynamic_sidebar('pragyan_home_page_main_content_area'); ?>
			</div>
			<div class="col-md-4">
				<?php dynamic_sidebar('pragyan_home_page_sidebar'); ?>
			</div>
		</div>
	</div>
</div>
