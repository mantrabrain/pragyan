<div class="pragyan-after-home-page-main-content-area">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-12">
				<?php dynamic_sidebar('pragyan_after_home_page_main_content_area'); ?>
			</div>
		</div>
	</div>
</div>
