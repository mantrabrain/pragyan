<?php

get_header();

pragyan_before_content();

pragyan_content();

pragyan_after_content();

get_footer();
