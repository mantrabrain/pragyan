<?php

$wp_customize->add_section(new Pragyan_Customizer_Section(
	$wp_customize,
	'pragyan_single_page_section', array(
	'title' => esc_html__('Single Page', 'pragyan'),
	'panel' => PRAGYA_THEME_OPTION_PANEL,
	'priority' => 400,
)));

